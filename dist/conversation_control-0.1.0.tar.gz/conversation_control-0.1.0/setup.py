from setuptools import setup

setup(
	name="conversation_control",
	packages=["conversation_control"],
	version="0.1.0",
	description="Este es un paquete de codigo, que busca continuar el control de conversacion, usando la herramienta de langchain",
	author="Jesus Zerpa",
	author_email="jesus26abraham1996@gmail.com",
	url="https://zerpatechnology.com/conversation_control",
	keywords=["langchain","python"]
	) 
